import { Component } from '@angular/core';
import { AuthService } from '../services/auth.service';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'app-registro',
  templateUrl: './registro.page.html',
  styleUrls: ['./registro.page.scss'],
})
export class RegistroPage {
  email: string = '';
  password: string = '';
  username: string = '';
  phone: string = '';
  address: string = '';

  constructor(private authService: AuthService, private navCtrl: NavController) {}

  register() {
    if (!this.email || !this.password || !this.username || !this.phone || !this.address) {
      console.error('Por favor llena todos los campos');
      return;
    }

    this.authService.registerUser(this.email, this.password, this.username, this.phone, this.address)
      .then(() => {
        this.navCtrl.navigateRoot('/home');
      })
      .catch(error => {
        console.error(error);
      });
  }

  volver() {
    this.navCtrl.navigateBack('/home');
  }
}
