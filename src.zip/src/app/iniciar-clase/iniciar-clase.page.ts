import { Component } from '@angular/core';

@Component({
  selector: 'app-iniciar-clase',
  templateUrl: './iniciar-clase.page.html',
  styleUrls: ['./iniciar-clase.page.scss'],
})

export class IniciarClasePage {
  className: string = '';
  description: string = '';
  students = [
    { name: 'Pepito Pepino', time: '10m' },
    { name: 'Bastian Salgado', time: '10m' },
    { name: 'Matias Hidalgo', time: '10m' }
  ];

  constructor() {}

  // Aquí podrías agregar métodos para manejar la lógica de la clase
}

