import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ClaseIniciadaPage } from './clase-iniciada.page';

describe('ClaseIniciadaPage', () => {
  let component: ClaseIniciadaPage;
  let fixture: ComponentFixture<ClaseIniciadaPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(ClaseIniciadaPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
