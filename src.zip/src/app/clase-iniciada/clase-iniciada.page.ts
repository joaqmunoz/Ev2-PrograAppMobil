import { Component } from '@angular/core';
import { QRCodeModule } from 'angularx-qrcode';

@Component({
  selector: 'app-clase-iniciada',
  templateUrl: './clase-iniciada.page.html',
  styleUrls: ['./clase-iniciada.page.scss'],
})
export class ClaseIniciadaPage {
  qrCodeValue: string;
  expiryTime: number;
  students: Array<{ name: string; time: string }>; // Definir la propiedad students

  constructor() {
    this.qrCodeValue = 'https://ejemplo.com/clase'; // Cambia esto a tu valor
    this.expiryTime = 15 * 60 * 1000; // 15 minutos
    this.students = []; // Inicializa la lista de estudiantes
  }

  ngOnInit() {
    setTimeout(() => {
      this.qrCodeValue = ''; // Caducar el código QR después de 15 minutos
    }, this.expiryTime);
  }

  // Método para agregar un estudiante (ejemplo)
  addStudent(name: string) {
    const currentTime = new Date().toLocaleTimeString();
    this.students.push({ name, time: currentTime });
  }
}
