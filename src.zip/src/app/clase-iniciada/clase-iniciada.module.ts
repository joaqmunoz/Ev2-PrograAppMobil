import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { ClaseIniciadaPageRoutingModule } from './clase-iniciada-routing.module';
import { ClaseIniciadaPage } from './clase-iniciada.page';
import { QRCodeModule } from 'angularx-qrcode'; // Importa el módulo

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ClaseIniciadaPageRoutingModule,
    QRCodeModule // Agrega QRCodeModule aquí
  ],
  declarations: [ClaseIniciadaPage]
})
export class ClaseIniciadaPageModule {}