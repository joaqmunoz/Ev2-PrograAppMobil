import { Component, Input } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { NavController } from '@ionic/angular';
import { AuthService } from '../services/auth.service'; // Asegúrate de que la ruta es correcta
import { User } from '../models/user.model';


@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage {
  @Input() control!: FormControl;
  @Input() type!: string;
  @Input() label!: string;
  @Input() autocomplete!: string;
  @Input() icon!: string;

  isPassword!: boolean;
  hide: boolean = true;
  
  form = new FormGroup({
    email: new FormControl('', [Validators.required, Validators.email]),
    password: new FormControl('', [Validators.required])
  });

  constructor(
    private navCtrl: NavController,
    private authService: AuthService // Inyecta AuthService aquí
  ) {}

  showOrHidePassword() {
    this.hide = !this.hide;
    this.type = this.hide ? 'password' : 'text'; // Puedes simplificar esta línea
  }

  volver() {
    this.navCtrl.navigateBack('/home');
  }

  submit() {
    if (this.form.valid) {
      const email = this.form.get('email')?.value;
      const password = this.form.get('password')?.value;
  
      if (email && password) {
        this.authService.signIn(email, password).then(userData => {
          if (userData) {
            console.log('Login exitoso:', userData);
            
            // Redirige según el rol del usuario
            switch (userData.role) {
              case 'admin':
                this.navCtrl.navigateForward('/admin');
                break;
              case 'profesor':
                this.navCtrl.navigateForward('/profesor');
                break;
              case 'alumno':
                this.navCtrl.navigateForward('/alumno');
                break;
              default:
                console.error('Rol de usuario no reconocido');
                break;
            }
          } else {
            console.error('Usuario no encontrado');
          }
        }).catch(err => {
          console.error('Error durante el login:', err);
        });
      } else {
        console.error('Falta email o contraseña');
      }
    } else {
      console.error('Formulario inválido');
    }
  }
}
