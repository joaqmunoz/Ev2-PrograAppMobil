import { TestBed } from '@angular/core/testing';
import { AuthGuard } from '../services/auth.guard';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import { Router } from '@angular/router';

describe('AuthGuard', () => {
  let guard: AuthGuard;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        AuthGuard,
        { provide: AngularFireAuth, useValue: {} },  // Provee dependencias si es necesario
        { provide: Router, useValue: {} }  // Provee dependencias si es necesario
      ]
    });
    guard = TestBed.inject(AuthGuard);  // Inyectar el guard
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();  // Prueba básica
  });
});

