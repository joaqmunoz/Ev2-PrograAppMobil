import { Injectable } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import { AngularFirestore } from '@angular/fire/compat/firestore';
import { User } from '../models/user.model'; 
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  constructor(private afAuth: AngularFireAuth, private firestore: AngularFirestore, private router: Router) {}

  async signIn(email: string, password: string): Promise<User | null> {
    try {
      const credential = await this.afAuth.signInWithEmailAndPassword(email, password);
      const user = credential.user;

      if (user) {
        const userDoc = await this.firestore.collection<User>('users', ref => ref.where('email', '==', email)).get().toPromise();
        if (!userDoc.empty) {
          const userData = userDoc.docs[0].data() as User;
          return userData;
        }
      }
      return null;
    } catch (error) {
      console.error('Error en la autenticación:', error);
      return null;
    }
  }

  registerUser(email: string, password: string, username: string, phone: string, address: string) {
    return this.afAuth.createUserWithEmailAndPassword(email, password)
      .then((userCredential) => {
        const user = userCredential.user;
        return this.firestore.collection('users').doc(user?.uid).set({
          username: username,
          phone: phone,
          address: address,
          email: email
        });
      });
  }
}

