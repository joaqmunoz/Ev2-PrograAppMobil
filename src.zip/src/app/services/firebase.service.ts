import { Injectable, inject } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import { getAuth, signInWithEmailAndPassword } from 'firebase/auth';
import { User } from '../models/user.model';
import { AngularFirestore } from '@angular/fire/compat/firestore'; // o `@angular/fire/firestore` para la nueva API


@Injectable({
  providedIn: 'root'
})

export class FirebaseService {

  auth = inject(AngularFireAuth);

  constructor(private firestore: AngularFirestore) {}

  async getUserRole(email: string): Promise<string | null> {
    const userDoc = await this.firestore.collection('users', ref => ref.where('email', '==', email)).get().toPromise();
    if (!userDoc.empty) {
      const userData = userDoc.docs[0].data();
      return userData.role;
    }
    return null;
  }



// ============================= Autenticacion =========================================
signIn(user: User) {
  return signInWithEmailAndPassword(getAuth(), user.email, user.password);
}

async logAllUsers() {
  const userCollection = this.firestore.collection<User>('users');
  const snapshot = await userCollection.get().toPromise();
  
  snapshot.docs.forEach(doc => {
    const userData = doc.data() as User;
    console.log(`Email: ${userData.email}, Role: ${userData.role}`); // Imprime el email y el rol
  });
}


}
