import { Component, OnInit, ViewChild } from '@angular/core';
import { TemplateRef } from '@angular/core';
import { PopoverController } from '@ionic/angular';


@Component({
  selector: 'app-narvar',
  templateUrl: './narvar.component.html',
  styleUrls: ['./narvar.component.scss'],
})
export class NarvarComponent  implements OnInit {
  @ViewChild('popover', { static: true }) popover: TemplateRef<any>;

  constructor(private popoverController: PopoverController) { }

  ngOnInit() {}

  async presentPopover(ev: any) {
    const popover = await this.popoverController.create({
      component: this.popover,
      event: ev,
      translucent: true,
    });
    await popover.present();
  }

  openSettings() {
    console.log('Abrir ajustes');
  }

  logout() {
    console.log('Cerrar sesión');
  }
}
