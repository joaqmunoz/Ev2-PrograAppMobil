export interface User{
    email: string,
    password: string,
    alumno: string,
    numberphone: number,
    direction: string
    role: 'admin' | 'profesor' | 'alumno'; 

}